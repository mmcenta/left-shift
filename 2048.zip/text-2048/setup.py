from setuptools import setup

setup(name='text2048',
      version='0.0.1',
      install_requires=['gym']
)
